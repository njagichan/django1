from django.contrib import admin
from solid_api import models

admin.site.register(models.drinks)
